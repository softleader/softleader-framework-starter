package {pkg}.example.dao;

import tw.com.softleader.data.dao.GenericCrudCodeDao;
import {pkg}.example.entity.ExampleEntity;

public interface ExampleDao extends GenericCrudCodeDao<ExampleEntity, Long> {

}
